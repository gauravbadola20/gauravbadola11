package com.Trading.trading.model;

import com.Trading.trading.domain.VerificationType;
import lombok.Data;


@Data
public class TwoFactorAuth {

    private boolean isEnabled = false;
    private VerificationType snedTo;

}
