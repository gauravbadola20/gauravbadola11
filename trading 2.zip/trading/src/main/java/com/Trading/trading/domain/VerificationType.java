package com.Trading.trading.domain;

public enum VerificationType {
    MOBILE,
    EMAIL
}
