package com.Trading.trading.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

   @GetMapping("/home")
   public String home() {
        return "welcome to my trading page";

    }

    @GetMapping("/api")
    public String about() {
        return "welcome to my trading page secure";
    }
}
