package com.Trading.trading.Service;

import com.Trading.trading.domain.VerificationType;
import com.Trading.trading.model.User;

public interface UserService {

    public User findUserProfileByJwt(String jwt) throws Exception;

    public User findUserByEmail(String email) throws Exception;

    public User findUserById(Long id) throws Exception;


    public User enableTwoFactorAuthentication(VerificationType verificationType, String sendTo, User user);

    User updatePassword(User user, String newPassword);





}
