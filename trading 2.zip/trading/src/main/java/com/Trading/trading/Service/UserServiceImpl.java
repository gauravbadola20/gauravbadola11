package com.Trading.trading.Service;

import com.Trading.trading.Repository.UserRepository;
import com.Trading.trading.config.JwtProvider;
import com.Trading.trading.domain.VerificationType;
import com.Trading.trading.model.TwoFactorAuth;
import com.Trading.trading.model.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;


@Slf4j
@Service
public class UserServiceImpl implements UserService{


    @Autowired
    private UserRepository userRepository;
    @Override
    public User findUserProfileByJwt(String jwt) throws Exception {

        String email = JwtProvider.getEmailFromToken(jwt);
        User user = userRepository.findByEmail(email);

        log.info("User found with email:"+email);

        if(user == null){
            throw new Exception("User not found");
        }
        return user;
    }

    @Override
    public User findUserByEmail(String email) throws Exception {
        User user = userRepository.findByEmail(email);

        if(user == null){
            throw new Exception("User not found");
        }
        return user;
    }

    @Override
    public User findUserById(Long id) throws Exception {

        Optional<User> user = userRepository.findById(id);

        if(user.isEmpty()){
            throw new Exception("user not found");
        }
        return user.get();
    }

    @Override
    public User enableTwoFactorAuthentication(VerificationType verificationType, String sendTo, User user) {

        TwoFactorAuth twoFactorAuth = new TwoFactorAuth();
        twoFactorAuth.setEnabled(true);
        twoFactorAuth.setSnedTo(verificationType);

        user.setTwoFactorAuth(twoFactorAuth);




        return userRepository.save(user);
    }


    @Override
    public User updatePassword(User user, String newPassword) {

        user.setPassword(newPassword);
        return userRepository.save(user);
    }
}
