package com.Trading.trading.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSendException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.annotation.processing.Filer;
import java.io.File;


@Service
public class EmailService {

    private JavaMailSender javaMailSender;

    public void sendVerificationEmail(String email, String otp) throws MessagingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, "utf-8");

        String subject = "Verfy OTP";

        String text = "Your verification code is " + otp;

        mimeMessageHelper.setSubject(subject);
        mimeMessageHelper.setText(text);
        mimeMessageHelper.setTo(email);

        try {
            javaMailSender.send(mimeMessage);
        } catch (MailException e) {
            throw new MailSendException(e.getMessage());
        }
    }

    public void sendEmail(String email, String otp) throws MessagingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, "utf-8");
        String subject = "verify OTP";

        String text = "Your verification code is " + otp;

        mimeMessageHelper.setSubject(subject);
        mimeMessageHelper.setText(text);
        mimeMessageHelper.setTo(email);

        try {
            javaMailSender.send(mimeMessage);
        } catch (MailException e) {
            e.printStackTrace();
            throw new MailSendException(e.getMessage());
        }
    }

    public void sendEmailWithAttachment(String to, String subject, String message, String path) throws MessagingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
        mimeMessageHelper.setSubject(subject);
        mimeMessageHelper.setText(message);
        mimeMessageHelper.setTo(to);
        mimeMessageHelper.addAttachment("Invoice", new File("path/to/invoice.pdf"));

        try {
            javaMailSender.send(mimeMessage);

        } catch (MailException e) {
            e.printStackTrace();
            throw new MailSendException(e.getMessage());
        }


    }

    public void sendEmailWithAttachment3(String to, String subject, String message, String path) throws MessagingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
        mimeMessageHelper.setSubject(subject);
        mimeMessageHelper.setText(message);
        mimeMessageHelper.setTo(to);
        mimeMessageHelper.addAttachment("Invoice", new File("path/to/invoice.pdf"));

        mimeMessageHelper.addAttachment("Invoice", new File("path/to/invoice.pdf"));
           String path2 = "path/to/invoice.pdf";
           mimeMessageHelper.addAttachment("Invoice", new File("path/to/invoice.pdf"));







        try{
            javaMailSender.send(mimeMessage);
        }catch (MailException e) {
            e.printStackTrace();
            throw new MailSendException(e.getMessage());
        }
    }

    //send file through email
    public void sendEmailWithFile(String to, String subject, String message, String path) throws MessagingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
        mimeMessageHelper.setSubject(subject);
        mimeMessageHelper.setText(message);
        mimeMessageHelper.setTo(to);

        // use the dynamic path as a method arguments
        File file = new File(path);

        if(file.exists()) {
            mimeMessageHelper.addAttachment(file.getName(), file);
        }else {
            throw new MessagingException("Attachment not found at path: " + path);
        }
        try{
            javaMailSender.send(mimeMessage);
        }catch (MailException e) {
            e.printStackTrace();
            throw new MailSendException(e.getMessage());
        }


    }



    public void sendEmailWithAttachments(String to, String subject, String message, String path) throws MessagingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
        mimeMessageHelper.setSubject(subject);
        mimeMessageHelper.setText(message);
        mimeMessageHelper.setTo(to);

        // Use the dynamic path provided as a method argument
        File file = new File(path);
        File fileName = new File(path);

        fileName.getName();

        if (file.exists()) {
            mimeMessageHelper.addAttachment(file.getName(), file);
        } else {
            throw new MessagingException("Attachment not found at path: " + path);
        }

        try {
            javaMailSender.send(mimeMessage);
        } catch (MailException e) {
            e.printStackTrace();
            throw new MailSendException(e.getMessage());
        }


    }
}
