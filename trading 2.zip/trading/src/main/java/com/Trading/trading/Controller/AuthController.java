package com.Trading.trading.Controller;

import com.Trading.trading.Repository.UserRepository;
import com.Trading.trading.Response.AuthResponse;
import com.Trading.trading.Service.CustomUserDetailService;
import com.Trading.trading.Service.EmailService;
import com.Trading.trading.Service.TwoFactorOtpService;
import com.Trading.trading.config.JwtProvider;
import com.Trading.trading.model.TwoFactorOTP;
import com.Trading.trading.model.User;
import com.Trading.trading.utils.OtpUtils;
import jakarta.mail.MessagingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;




@RestController
@RequestMapping("/auth")
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);
    @Autowired
   private UserRepository userRepository;

   @Autowired
   private CustomUserDetailService customUserDetailService; // CustomUserDetailService

   @Autowired
   private TwoFactorOtpService twoFactorOtpService;

  @Autowired
  private EmailService emailService;


    @PostMapping("/singup")
    public ResponseEntity<AuthResponse> registers(@RequestBody User user) {


        User isEmailExist = userRepository.findByEmail(user.getEmail());

        if(isEmailExist != null){
            throw new RuntimeException("Email already exist");
        }
        User newUser = new User();
        newUser.setFullName(user.getFullName());
        newUser.setEmail(user.getEmail());
        newUser.setPassword(user.getPassword());

        User savedUser = userRepository.save(newUser);//there coould be a problem


        //TODO: send email

        Authentication auth = new UsernamePasswordAuthenticationToken(
                user.getEmail(),
                user.getPassword()

        );

        SecurityContextHolder.getContext().setAuthentication(auth);

        String jwt = JwtProvider.generateToken(auth);

        AuthResponse res = new AuthResponse();
        res.setJwt(jwt);
        res.setStatus(true);
        res.setMessage("register success");
        res.setSession("register success");

        log.info("the user register successfully"+res.toString());

        return  new ResponseEntity<>(res, HttpStatus.CREATED);


    }


    //creted the login method
    @PostMapping("/singin")
    public ResponseEntity<AuthResponse> login(@RequestBody User user) throws MessagingException {

        String userName = user.getEmail();
        String password = user.getPassword();

        Authentication auth = authentication(userName, password);

        SecurityContextHolder.getContext().setAuthentication(auth);

        String jwt = JwtProvider.generateToken(auth);

        User authUser = userRepository.findByEmail(userName);

        if(user.getTwoFactorAuth().isEnabled()){
            AuthResponse res = new AuthResponse();
            res.setMessage("The two factor is enabled");
            res.setTwoFactorAuthEnabled(true);
            String otp = OtpUtils.generateOtp();


            TwoFactorOTP oldTwoFactorOTP = twoFactorOtpService.findByUser(authUser.getId());

            if(oldTwoFactorOTP != null){
                twoFactorOtpService.deleteTwoFactorOTP(oldTwoFactorOTP);
            }
            TwoFactorOTP newTwoFactorOTP = twoFactorOtpService.createTwoFactorOTP(authUser, otp, jwt);


            emailService.sendVerificationEmail(userName, otp);

           res.setSession(newTwoFactorOTP.getId());
            return  new ResponseEntity<>(res, HttpStatus.CREATED);

        }

        AuthResponse res = new AuthResponse();
        res.setJwt(jwt);
        res.setStatus(true);
        res.setMessage("login success");
        res.setSession("login success");

        return  new ResponseEntity<>(res, HttpStatus.CREATED);


    }

    private Authentication authentication(String userName, String password) {
        UserDetails userDetails = customUserDetailService.loadUserByUsername(userName);

        if(userDetails == null) {
            throw new BadCredentialsException("invalid username");
        }

        if(!password.equals(userDetails.getPassword())){
            throw new BadCredentialsException("invalid password");
        }

        return new UsernamePasswordAuthenticationToken(userDetails, password, userDetails.getAuthorities());
    }



    public ResponseEntity<AuthResponse> verifySigningOtp(@PathVariable String otp,
                                                         @RequestParam String id)
            throws Exception {

        TwoFactorOTP twoFactorOTP = twoFactorOtpService.findById(id);

        if(twoFactorOtpService.verrifyTwoFactorOTP(twoFactorOTP, otp)){
            AuthResponse res = new AuthResponse();
            res.setMessage(" Two factor authentication verified successfully");
            res.setStatus(true);
            res.setJwt(twoFactorOTP.getJwt());
            return  new ResponseEntity<>(res, HttpStatus.OK);
        }
        throw new Exception("invalid otp");

    }




}

