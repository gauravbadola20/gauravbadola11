package com.Trading.trading.config;

public class JwtConstant {
    public static final String SECRET_KEY = "HGHGHGDJSGJGC625467UHUCSJCJGWEYU764828263TWU23838UDK3I8Y9EU2EJJKBFJ7T48Y3";
    public static final String JWT_HEADER = "Authorization";
}
