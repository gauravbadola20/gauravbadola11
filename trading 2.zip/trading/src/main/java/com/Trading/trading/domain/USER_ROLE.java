package com.Trading.trading.domain;

public enum USER_ROLE {
    ROLE_ADMIN,
    ROLE_CUSTOMER
}
