package com.JWT.example.JWTExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtExampleProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
