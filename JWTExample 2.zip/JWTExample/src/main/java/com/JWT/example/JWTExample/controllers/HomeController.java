package com.JWT.example.JWTExample.controllers;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JWT.example.JWTExample.Models.JwtRequest;
import com.JWT.example.JWTExample.Models.Model;
import com.JWT.example.JWTExample.Services.Services;

@RestController
@RequestMapping("/home")
public class HomeController {
	
	
	@Autowired
	private Services services;
	

	@GetMapping("/user")
	
	public List<Model> getUserInfo() {
		return this.services.getUsers();
		

	}
	@GetMapping("/current-user")
	public String getLoggedInUser(Principal principal) {
		return principal.getName();
		
		
	}
	

}
