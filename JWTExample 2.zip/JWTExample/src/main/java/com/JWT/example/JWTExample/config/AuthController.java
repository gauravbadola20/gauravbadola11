//package com.JWT.example.JWTExample.config;
//
//public record AuthController() {

//}
