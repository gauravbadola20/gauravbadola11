package com.JWT.example.JWTExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtExampleProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtExampleProjectApplication.class, args);
		
	}

}
