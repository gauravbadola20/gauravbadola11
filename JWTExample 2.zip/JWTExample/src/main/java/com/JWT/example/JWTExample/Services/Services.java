package com.JWT.example.JWTExample.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.JWT.example.JWTExample.Models.Model;





@Service

public class Services {
	
	private List<Model> store = new ArrayList<>();

	public Services() {
		
		store.add(new Model(UUID.randomUUID().toString(),"GAURAV","ABC2gmail.com"));
		store.add(new Model(UUID.randomUUID().toString(),"Anshul","AC2gmail.com"));
		store.add(new Model(UUID.randomUUID().toString(),"Akash","BC2gmail.com"));
		store.add(new Model(UUID.randomUUID().toString(),"Akash2","ABcC2gmail.com"));
		store.add(new Model(UUID.randomUUID().toString(),"Tom","abcde@gamil.com"));
		

		
		
		
		
	
	}
	public List<Model> getUsers(){
		return this.store;
	}
	

}
